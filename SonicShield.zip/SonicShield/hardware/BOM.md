# Bill of Materials (draft)

| Item | Qty | Notes |
|---|---|---|
| ESP32 dev board | 1 | ADC + WiFi |
| Resistor 100 kΩ | 1 | Voltage divider R1 (adjust to panel voltage) |
| Resistor 33 kΩ | 1 | Voltage divider R2 |
| Small solar panel | 1 | For bench testing |
| Piezoelectric transducer | 1 | To be selected |
| SAW driver stage | 1 | Design pending |
| Breadboard + jumper wires | 1 set | Prototyping |

Add part numbers, datasheets (in `/docs`) and costs as the design is finalised.
